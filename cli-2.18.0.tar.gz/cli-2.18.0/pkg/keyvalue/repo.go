package keyvalue

import (
	"context"
	"errors"
	"net/http"

	"github.com/render-oss/cli/pkg/client"
	"github.com/render-oss/cli/pkg/config"
)

// ErrKeyValueNotFound is returned by Repo.GetKeyValue when the API responds
// with a 404, so callers can distinguish "this ID doesn't exist" from other
// failure modes (auth, network, 5xx) without parsing error messages.
var ErrKeyValueNotFound = errors.New("key value not found")

type Repo struct {
	client *client.ClientWithResponses
}

func NewRepo(c *client.ClientWithResponses) *Repo {
	return &Repo{
		client: c,
	}
}

func (r *Repo) ListKeyValue(ctx context.Context, params *client.ListKeyValueParams) ([]*client.KeyValue, error) {
	workspace, err := config.WorkspaceID()
	if err != nil {
		return nil, err
	}

	params.OwnerId = &client.OwnerIdParam{workspace}

	resp, err := r.client.ListKeyValueWithResponse(ctx, params)
	if err != nil {
		return nil, err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return nil, err
	}

	kvs := make([]*client.KeyValue, 0, len(*resp.JSON200))
	for _, kv := range *resp.JSON200 {
		kvs = append(kvs, &kv.KeyValue)
	}

	return kvs, nil
}

func (r *Repo) GetKeyValue(ctx context.Context, id string) (*client.KeyValueDetail, error) {
	resp, err := r.client.RetrieveKeyValueWithResponse(ctx, id)
	if err != nil {
		return nil, err
	}

	if resp.StatusCode() == http.StatusNotFound {
		return nil, ErrKeyValueNotFound
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return nil, err
	}

	return resp.JSON200, nil
}

func (r *Repo) GetKeyValueConnectionInfo(ctx context.Context, id string) (*client.KeyValueConnectionInfo, error) {
	resp, err := r.client.RetrieveKeyValueConnectionInfoWithResponse(ctx, id)
	if err != nil {
		return nil, err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return nil, err
	}

	return resp.JSON200, nil
}

// CreateKeyValue creates a Key Value instance via the Render API.
//
// Unlike the service repo, this method does not call validate.WorkspaceMatches
// on data.OwnerId. The cmd/kvcreate flow accepts a --workspace flag that may
// intentionally differ from the active workspace, and that check would block
// the override. Callers are responsible for resolving the correct OwnerId
// (e.g. validating workspace/project/environment consistency) before calling.
func (r *Repo) CreateKeyValue(ctx context.Context, data client.CreateKeyValueJSONRequestBody) (*client.KeyValueDetail, error) {
	resp, err := r.client.CreateKeyValueWithResponse(ctx, data)
	if err != nil {
		return nil, err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return nil, err
	}

	return resp.JSON201, nil
}

func (r *Repo) UpdateKeyValue(ctx context.Context, id string, data client.UpdateKeyValueJSONRequestBody) (*client.KeyValueDetail, error) {
	resp, err := r.client.UpdateKeyValueWithResponse(ctx, id, data)
	if err != nil {
		return nil, err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return nil, err
	}

	return resp.JSON200, nil
}

func (r *Repo) DeleteKeyValue(ctx context.Context, id string) error {
	resp, err := r.client.DeleteKeyValueWithResponse(ctx, id)
	if err != nil {
		return err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return err
	}

	return nil
}

func (r *Repo) SuspendKeyValue(ctx context.Context, id string) error {
	resp, err := r.client.SuspendKeyValueWithResponse(ctx, id)
	if err != nil {
		return err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return err
	}

	return nil
}

func (r *Repo) ResumeKeyValue(ctx context.Context, id string) error {
	resp, err := r.client.ResumeKeyValueWithResponse(ctx, id)
	if err != nil {
		return err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return err
	}

	return nil
}
