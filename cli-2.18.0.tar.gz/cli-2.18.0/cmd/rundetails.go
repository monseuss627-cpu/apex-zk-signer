package cmd

import (
	"fmt"

	wfclient "github.com/render-oss/cli/pkg/client/workflows"
	"github.com/render-oss/cli/pkg/command"
	"github.com/render-oss/cli/pkg/text"
	"github.com/render-oss/cli/pkg/tui/flows"
	workflowviews "github.com/render-oss/cli/pkg/tui/views/workflows"
	"github.com/spf13/cobra"
)

func NewRunDetailsCmd(deps flows.WorkflowDeps) *cobra.Command {
	return &cobra.Command{
		Use:   "show [taskRunID]",
		Short: "Show detailed information about a task run",
		Long: `Display detailed information about a specific task run execution.

This command shows comprehensive information about a task run, including:
  • Task run ID and status
  • Input parameters provided
  • Output or error result
  • Start and completion timestamps

The task run ID is returned when you execute a task with:
  render workflows tasks runs start

In interactive mode, you will be prompted to select a task run if not provided.`,
		Example: `  # Show details for a task run
  render workflows tasks runs show trn-1234

  # Show details from local workflow development server
  render workflows tasks runs show --local trn-5678`,
		RunE: func(cmd *cobra.Command, args []string) error {
			deps, local, err := getLocalDeps(cmd, deps)
			if err != nil {
				return fmt.Errorf("failed to get local deps: %w", err)
			}

			var input workflowviews.TaskRunTargetInput
			err = command.ParseCommand(cmd, args, &input)
			if err != nil {
				return fmt.Errorf("failed to parse command: %w", err)
			}

			if nonInteractive, err := command.NonInteractive(cmd, func() (*wfclient.TaskRunDetails, error) {
				res, err := deps.WorkflowLoader().LoadTaskRunDetails(cmd.Context(), &input)
				return res, err
			}, text.TaskRunDetails); err != nil {
				return err
			} else if nonInteractive {
				return nil
			}

			flows.NewWorkflow(deps, flows.NewLogFlow(deps, flows.WithLocal(local)), local).RunDetailsFlow(cmd.Context(), &input)

			return nil
		},
	}
}
