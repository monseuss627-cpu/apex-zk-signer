package cmd

import (
	"fmt"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/spf13/cobra"

	wfclient "github.com/render-oss/cli/pkg/client/workflows"
	"github.com/render-oss/cli/pkg/command"
	"github.com/render-oss/cli/pkg/dependencies"
	"github.com/render-oss/cli/pkg/pointers"
	"github.com/render-oss/cli/pkg/text"
	"github.com/render-oss/cli/pkg/tui/flows"
	"github.com/render-oss/cli/pkg/tui/views"
	wfviews "github.com/render-oss/cli/pkg/tui/views/workflows"
	"github.com/render-oss/cli/pkg/types"
	"github.com/render-oss/cli/pkg/utils"
)

var workflowRuntimeValues = []string{
	string(wfclient.Node),
	string(wfclient.Python),
	string(wfclient.Go),
	string(wfclient.Ruby),
	string(wfclient.Elixir),
}

var workflowAutoDeployTriggerValues = []string{
	string(wfclient.Commit),
	string(wfclient.Off),
	string(wfclient.ChecksPass),
}

var WorkflowCreateCmd = &cobra.Command{
	Use:   "create",
	Short: "Create a new workflow service",
	Args:  cobra.NoArgs,
	Long: `Create a new workflow service on Render.

In interactive mode, a form guides you through the required fields.
In non-interactive mode, provide all required config with flags.

Environment variables (non-interactive only for now):
  • Pass individual vars with --env-var KEY=VALUE (repeatable).
  • Load from one or more .env files with --env-file PATH (repeatable). Every
    listed file must exist.
  • Inline --env-var values override values from --env-file.

Examples:
  render workflows create
  render workflows create --name my-workflow --repo https://github.com/org/repo --build-command "npm install" --runtime node --run-command "npm start" --region oregon -o json
  render workflows create --repo . --name my-workflow --build-command "npm install" --runtime node --run-command "npm start"
  render workflows create --repo . --name my-workflow --build-command "pip install -r requirements.txt" --runtime python --run-command ".venv/bin/python main.py" --env-file .env.production --env-var LOG_LEVEL=debug
`,
}

func init() {
	WorkflowCreateCmd.RunE = func(cmd *cobra.Command, args []string) error {
		var input wfviews.WorkflowCreateInput

		if err := command.ParseCommand(cmd, args, &input); err != nil {
			return fmt.Errorf("failed to parse input: %w", err)
		}

		if input.Repo != nil && *input.Repo != "" {
			resolved, err := utils.ResolveLocalRepoURL(*input.Repo)
			if err != nil {
				return fmt.Errorf("--repo %q: %w", *input.Repo, err)
			}
			input.Repo = &resolved
		}

		envFiles, err := cmd.Flags().GetStringSlice("env-file")
		if err != nil {
			return fmt.Errorf("failed to get --env-file: %w", err)
		}
		fileVars, _, err := utils.LoadEnvFiles(envFiles, true)
		if err != nil {
			return err
		}
		// File values come first; inline --env-var values (already on
		// input.EnvVars) appear after so they win on duplicate keys when
		// resolveEnvVars merges them in order.
		input.EnvVars = append(utils.EnvMapToKVStrings(fileVars), input.EnvVars...)

		if nonInteractive, err := command.NonInteractive(cmd, func() (*wfclient.Workflow, error) {
			return wfviews.CreateWorkflow(cmd.Context(), input)
		}, func(w *wfclient.Workflow) string {
			return text.FormatStringF("Created workflow %s (%s)", w.Name, w.Id)
		}); err != nil {
			return err
		} else if nonInteractive {
			return nil
		}

		interactiveWorkflowCreate(cmd, &input)
		return nil
	}

	WorkflowCreateCmd.Flags().String("name", "", "Workflow name. Required in non-interactive mode.")
	WorkflowCreateCmd.Flags().String("repo", "", "Git repository URL, or a local directory path (e.g. '.') to resolve via the repo's origin remote. Required in non-interactive mode.")
	WorkflowCreateCmd.Flags().String("branch", "", "Git branch (Optional)")
	runtimeFlag := command.NewEnumInput(workflowRuntimeValues, false)
	WorkflowCreateCmd.Flags().Var(runtimeFlag, "runtime", "Runtime (node, python, go, ruby, elixir). Required in non-interactive mode.")
	WorkflowCreateCmd.Flags().String("build-command", "", "Build command. Required in non-interactive mode.")
	WorkflowCreateCmd.Flags().String("run-command", "", "Command to run the workflow. Required in non-interactive mode.")
	regionFlag := command.NewEnumInput(types.RegionValues(), false)
	WorkflowCreateCmd.Flags().Var(regionFlag, "region", "Deployment region (default: oregon)")
	WorkflowCreateCmd.Flags().String("root-directory", "", "Root directory in the repository (Optional)")
	autoDeployFlag := command.NewEnumInput(workflowAutoDeployTriggerValues, false)
	WorkflowCreateCmd.Flags().Var(autoDeployFlag, "auto-deploy-trigger", "Autodeploy behavior (commit, off, checksPass; default: commit)")
	WorkflowCreateCmd.Flags().StringArray("env-var", nil, "Set environment variables in KEY=VALUE format (can be specified multiple times). Inline values override values loaded from --env-file.")
	WorkflowCreateCmd.Flags().StringSlice("env-file", nil, "Path to an env file to load. Repeat to load multiple files (later files override earlier ones). Every listed file must exist.")
	setAnnotationBestEffort(WorkflowCreateCmd.Flags(), "env-var", command.FlagPlaceholderAnnotation, []string{"KEY_VALUE"})
	setAnnotationBestEffort(WorkflowCreateCmd.Flags(), "env-file", command.FlagPlaceholderAnnotation, []string{"PATH"})
}

func interactiveWorkflowCreate(cmd *cobra.Command, input *wfviews.WorkflowCreateInput) tea.Cmd {
	ctx := cmd.Context()
	deps := dependencies.GetFromContext(ctx)

	// Set defaults for enum fields so the interactive form cursor starts
	// on the right value instead of the first item alphabetically.
	if input.Region == nil {
		input.Region = pointers.From("oregon")
	}
	if input.AutoDeployTrigger == nil {
		input.AutoDeployTrigger = pointers.From(string(wfclient.Commit))
	}
	return command.AddToStackFunc(
		ctx,
		cmd,
		"Create Workflow",
		input,
		wfviews.NewWorkflowCreateView(ctx, input, WorkflowCreateCmd, wfviews.CreateWorkflow, func(w *wfclient.Workflow) tea.Cmd {
			if w.AutoDeployTrigger == nil || *w.AutoDeployTrigger == wfclient.Off {
				return nil
			}
			return flows.NewLogFlow(deps).LogsFlow(ctx, views.LogInput{
				ResourceIDs: []string{w.Id},
				Tail:        true,
			})
		}),
	)
}
